package com.code.page.ibnmsConfig.envList.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 2014/7/9.
 */
public class EnvBtnPage extends BtnPage {
    public EnvBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
