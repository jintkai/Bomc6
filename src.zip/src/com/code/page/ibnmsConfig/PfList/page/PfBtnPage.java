package com.code.page.ibnmsConfig.PfList.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 2014/7/11.
 */
public class PfBtnPage extends BtnPage {
    public PfBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
