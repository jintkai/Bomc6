package com.code.page.ibnmsConfig.collModelList;

import com.code.common.Page;

/**
 * Created by jinkai on 2014/7/16.
 */
public class CollModelListPage extends Page {

}
