package com.code.page.ibnmsConfig.kbplist.domain;

/**
 * Created by jon on 16/5/4.
 */
public class SearchKbpDomain {
    private String kbp_class;
    private String kbp_Caption;

}
