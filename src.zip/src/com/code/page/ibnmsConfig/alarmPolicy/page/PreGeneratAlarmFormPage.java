package com.code.page.ibnmsConfig.alarmPolicy.page;

import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by Jin on 2014/8/13.
 */
public class PreGeneratAlarmFormPage extends GeneratAlarmFormPage {
    public PreGeneratAlarmFormPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
    public String title="预警生成策略配置";

}
