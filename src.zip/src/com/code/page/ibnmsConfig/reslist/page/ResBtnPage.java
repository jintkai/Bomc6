package com.code.page.ibnmsConfig.reslist.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 07/07/2014.
 */
public class ResBtnPage extends BtnPage {
    public ResBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
