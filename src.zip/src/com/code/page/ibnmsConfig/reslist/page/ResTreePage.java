package com.code.page.ibnmsConfig.reslist.page;

import com.code.common.TreePage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 07/07/2014.
 */
public class ResTreePage extends TreePage{
    public ResTreePage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
