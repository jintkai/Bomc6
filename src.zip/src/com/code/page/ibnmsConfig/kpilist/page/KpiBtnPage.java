package com.code.page.ibnmsConfig.kpilist.page;

import com.code.common.BtnPage;
import com.code.common.Data;
import com.code.common.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 06/07/2014.
 * Kpi页面的操作类
 */
public class KpiBtnPage extends BtnPage{
    public KpiBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }

}
