package com.code.page.ibnmsConfig.kpilist.domain;

/**
 * Created by jon on 16/5/10.
 */
public class KpiFormDomain {
    private String KPI_ID;
    private String KBP_CLASS;
    private String KPI_NAME;
    private String KPI_STYLE;
    private String KPI_MEASURE;
    private String KPI_RANG;
    private String KPI_DESC;

    public String getKPI_ID() {
        return KPI_ID;
    }

    public void setKPI_ID(String KPI_ID) {
        this.KPI_ID = KPI_ID;
    }

    public String getKBP_CLASS() {
        return KBP_CLASS;
    }

    public void setKBP_CLASS(String KBP_CLASS) {
        this.KBP_CLASS = KBP_CLASS;
    }

    public String getKPI_NAME() {
        return KPI_NAME;
    }

    public void setKPI_NAME(String KPI_NAME) {
        this.KPI_NAME = KPI_NAME;
    }

    public String getKPI_STYLE() {
        return KPI_STYLE;
    }

    public void setKPI_STYLE(String KPI_STYLE) {
        this.KPI_STYLE = KPI_STYLE;
    }

    public String getKPI_MEASURE() {
        return KPI_MEASURE;
    }

    public void setKPI_MEASURE(String KPI_MEASURE) {
        this.KPI_MEASURE = KPI_MEASURE;
    }

    public String getKPI_RANG() {
        return KPI_RANG;
    }

    public void setKPI_RANG(String KPI_RANG) {
        this.KPI_RANG = KPI_RANG;
    }

    public String getKPI_DESC() {
        return KPI_DESC;
    }

    public void setKPI_DESC(String KPI_DESC) {
        this.KPI_DESC = KPI_DESC;
    }
}
