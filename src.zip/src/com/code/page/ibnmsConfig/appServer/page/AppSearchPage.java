package com.code.page.ibnmsConfig.appServer.page;

import com.code.common.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Jin on 2014/8/10.
 */
public class AppSearchPage extends Page {
    @FindBy(id="applyModule")
    public WebElement applyModule;
}
