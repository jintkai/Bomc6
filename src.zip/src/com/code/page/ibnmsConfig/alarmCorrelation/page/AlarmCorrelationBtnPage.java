package com.code.page.ibnmsConfig.alarmCorrelation.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by Jin on 2014/9/11.
 */
public class AlarmCorrelationBtnPage extends BtnPage {
    public AlarmCorrelationBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
