package com.code.page.ibnmsConfig.alarmConfFilter;

import com.code.common.Page;

/**
 * Created by Jin on 2014/7/29.
 * 告警过滤列表
 */
public class AlarmConfFilterList extends Page {

}
