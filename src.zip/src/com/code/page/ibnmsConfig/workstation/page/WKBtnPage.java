package com.code.page.ibnmsConfig.workstation.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 2014/7/11.
 */
public class WKBtnPage extends BtnPage {
    public WKBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
