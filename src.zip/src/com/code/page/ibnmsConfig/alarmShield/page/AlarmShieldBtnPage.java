package com.code.page.ibnmsConfig.alarmShield.page;

import com.code.common.BtnPage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by Jin on 2014/9/4.
 */
public class AlarmShieldBtnPage extends BtnPage {
    public AlarmShieldBtnPage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
