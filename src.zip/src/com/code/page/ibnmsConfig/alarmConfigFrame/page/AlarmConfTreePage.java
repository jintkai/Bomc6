package com.code.page.ibnmsConfig.alarmConfigFrame.page;

import com.code.common.TreePage;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Created by jinkai on 2014/7/16.
 */
public class AlarmConfTreePage extends TreePage {
    public AlarmConfTreePage(EventFiringWebDriver eventDriver)
    {
        super(eventDriver);
    }
}
