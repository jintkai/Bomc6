package com.code.page.ibnmsConfig.alarmConfigFrame.page;

import com.code.common.Page;

/**
 * Created by Jin on 2014/8/12.
 */
public class AlarmGenerationFormPage extends Page {

}
