package com.code.page.C3P.instrFrame.page;

import com.code.common.Page;

/**
 * Created by jinkai on 2014/7/23.
 */
public class SQLFormPage extends Page {

}
