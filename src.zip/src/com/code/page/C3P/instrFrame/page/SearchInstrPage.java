package com.code.page.C3P.instrFrame.page;

import com.code.common.Page;
import org.openqa.selenium.WebElement;

/**
 * Created by jinkai on 2014/7/23.
 */
public class SearchInstrPage extends Page {
    WebElement scriptName;
    WebElement serachDesc;
    WebElement scriptUseStatus;
    WebElement createUser;
    WebElement findcriptType;
    WebElement controlType;
    WebElement subcontrolTypeHost;

}
