package com.code.common;

import com.code.common.Page;
import com.code.common.TestCase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by jinkai on 01/07/2014.
 */
public class HomePage extends Page {
}
