package com.code.common;

/**
 * Created by jinkai on 2014/6/22.
 */
public class Login {

}
